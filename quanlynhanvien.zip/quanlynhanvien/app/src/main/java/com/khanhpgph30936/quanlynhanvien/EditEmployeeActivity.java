package com.khanhpgph30936.quanlynhanvien;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class EditEmployeeActivity extends AppCompatActivity {

    private EditText nameInput, phoneInput, emailInput, addressInput;
    private Button saveButton;
    private DatabaseHelper dbHelper;
    private int employeeId;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_employee);

        nameInput = findViewById(R.id.nameInput);
        phoneInput = findViewById(R.id.phoneInput);
        emailInput = findViewById(R.id.emailInput);
        addressInput = findViewById(R.id.addressInput);
        saveButton = findViewById(R.id.updateButton);

        dbHelper = new DatabaseHelper(this);

        // Lấy dữ liệu nhân viên từ intent
        employeeId = getIntent().getIntExtra("employee_id", -1);
        String name = getIntent().getStringExtra("name");
        String phone = getIntent().getStringExtra("phone");
        String email = getIntent().getStringExtra("email");
        String address = getIntent().getStringExtra("address");

        // Hiển thị thông tin hiện tại
        nameInput.setText(name);
        phoneInput.setText(phone);
        emailInput.setText(email);
        addressInput.setText(address);

        saveButton.setOnClickListener(v -> {
            String newName = nameInput.getText().toString();
            String newPhone = phoneInput.getText().toString();
            String newEmail = emailInput.getText().toString();
            String newAddress = addressInput.getText().toString();

            if (newName.isEmpty() || newPhone.isEmpty() || newEmail.isEmpty() || newAddress.isEmpty()) {
                Toast.makeText(EditEmployeeActivity.this, "Vui lòng nhập đầy đủ thông tin!", Toast.LENGTH_SHORT).show();
            } else {
                // Cập nhật thông tin nhân viên
                dbHelper.updateEmployee(employeeId, newName, newPhone, newEmail, newAddress);
                Toast.makeText(EditEmployeeActivity.this, "Cập nhật thông tin thành công!", Toast.LENGTH_SHORT).show();
                finish();  // Đóng activity và trở lại màn hình quản lý
            }
        });
    }
}

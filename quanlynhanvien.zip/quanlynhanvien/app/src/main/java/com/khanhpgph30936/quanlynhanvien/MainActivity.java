package com.khanhpgph30936.quanlynhanvien;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ListView;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    private Button addEmployeeButton;
    private ListView employeeListView;
    private List<Employee> employeeList;
    private EmployeeAdapter adapter;
    private DatabaseHelper dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        addEmployeeButton = findViewById(R.id.addEmployeeButton);
        employeeListView = findViewById(R.id.employeeListView);

        dbHelper = new DatabaseHelper(this);

        // Load danh sách nhân viên
        loadEmployees();

        // Thêm nhân viên mới
        addEmployeeButton.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, AddEmployeeActivity.class);
            startActivity(intent);
        });

        // Xử lý khi nhấn vào một nhân viên
        employeeListView.setOnItemClickListener((parent, view, position, id) -> {
            Employee employee = employeeList.get(position);
            showEmployeeOptions(employee);
        });
    }

    private void loadEmployees() {
        Cursor cursor = dbHelper.getAllEmployees();
        employeeList = new ArrayList<>();

        while (cursor.moveToNext()) {
            int id = cursor.getInt(cursor.getColumnIndexOrThrow(DatabaseHelper.COLUMN_ID));
            String name = cursor.getString(cursor.getColumnIndexOrThrow(DatabaseHelper.COLUMN_NAME));
            String phone = cursor.getString(cursor.getColumnIndexOrThrow(DatabaseHelper.COLUMN_PHONE));
            String email = cursor.getString(cursor.getColumnIndexOrThrow(DatabaseHelper.COLUMN_EMAIL));
            String address = cursor.getString(cursor.getColumnIndexOrThrow(DatabaseHelper.COLUMN_ADDRESS));


            employeeList.add(new Employee(id, name, phone, email, address));
        }

        cursor.close();

        // Set up adapter and bind it to ListView
        adapter = new EmployeeAdapter(this, employeeList);
        employeeListView.setAdapter(adapter);
    }

    private void showEmployeeOptions(Employee employee) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setMessage("Chọn thao tác")
                .setPositiveButton("Sửa", (dialog, id) -> {
                    Intent intent = new Intent(MainActivity.this, EditEmployeeActivity.class);
                    intent.putExtra("employee_id", employee.getId());
                    intent.putExtra("name", employee.getName());
                    intent.putExtra("phone", employee.getPhone());
                    intent.putExtra("email", employee.getEmail());
                    intent.putExtra("address", employee.getAddress());
                    startActivity(intent);
                })
                .setNegativeButton("Xóa", (dialog, id) -> {
                    dbHelper.deleteEmployee(employee.getId());
                    Toast.makeText(MainActivity.this, "Đã xóa nhân viên", Toast.LENGTH_SHORT).show();
                    loadEmployees();  // Cập nhật lại danh sách
                })
                .show();
    }
}

package com.khanhpgph30936.quanlynhanvien;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class DatabaseHelper extends SQLiteOpenHelper {

    // Các tên cột
    public static final String COLUMN_ID = "id";
    public static final String COLUMN_NAME = "name";
    public static final String COLUMN_PHONE = "phone";
    public static final String COLUMN_EMAIL = "email";
    public static final String COLUMN_ADDRESS = "address";

    // Tạo bảng nhân viên
    private static final String CREATE_TABLE = "CREATE TABLE employees (" +
            COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
            COLUMN_NAME + " TEXT, " +
            COLUMN_PHONE + " TEXT, " +
            COLUMN_EMAIL + " TEXT, " +
            COLUMN_ADDRESS + " TEXT)";

    public DatabaseHelper(Context context) {
        super(context, "employee_db", null, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(CREATE_TABLE);

        // Kiểm tra và thêm dữ liệu mẫu vào cơ sở dữ liệu
        addDefaultEmployees(db);
    }

    // Kiểm tra và thêm nhân viên mẫu
    private void addDefaultEmployees(SQLiteDatabase db) {
        // Kiểm tra xem bảng employees có dữ liệu chưa
        Cursor cursor = db.rawQuery("SELECT COUNT(*) FROM employees", null);
        cursor.moveToFirst();
        int count = cursor.getInt(0);
        cursor.close();

        // Nếu bảng chưa có dữ liệu, thêm 2 nhân viên mẫu
        if (count == 0) {
            addEmployee( "Nguyễn Văn A", "0123456789", "a@example.com", "Hà Nội");
            addEmployee( "Trần Thị B", "0987654321", "b@example.com", "Hồ Chí Minh");
        }
    }

    // Thêm nhân viên vào cơ sở dữ liệu
    public void addEmployee(String name, String phone, String email, String address) {
        SQLiteDatabase db = this.getWritableDatabase();  // Lấy đối tượng SQLiteDatabase
        ContentValues values = new ContentValues();
        values.put(COLUMN_NAME, name);
        values.put(COLUMN_PHONE, phone);
        values.put(COLUMN_EMAIL, email);
        values.put(COLUMN_ADDRESS, address);

        db.insert("employees", null, values);  // Thêm nhân viên vào cơ sở dữ liệu
    }


    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS employees");
        onCreate(db);
    }

    // Lấy tất cả nhân viên từ cơ sở dữ liệu
    public Cursor getAllEmployees() {
        SQLiteDatabase db = this.getReadableDatabase();
        return db.rawQuery("SELECT * FROM employees", null);
    }

    // Xóa nhân viên
    public void deleteEmployee(int id) {
        SQLiteDatabase db = this.getWritableDatabase();
        db.delete("employees", COLUMN_ID + " = ?", new String[]{String.valueOf(id)});
    }

    // Cập nhật thông tin nhân viên
    public void updateEmployee(int id, String name, String phone, String email, String address) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_NAME, name);
        values.put(COLUMN_PHONE, phone);
        values.put(COLUMN_EMAIL, email);
        values.put(COLUMN_ADDRESS, address);

        db.update("employees", values, COLUMN_ID + " = ?", new String[]{String.valueOf(id)});
    }
}
